#ifndef BITSTREAM_H
#define BITSTREAM_H

#include <vector>

class BitStream {
private:
    std::vector<int> bits_;

public:
    BitStream();
    explicit BitStream(int size);

    void generateRandomBits(int size);
    const std::vector<int>& getBits() const;
};

#endif
#ifndef CHANNEL_H
#define CHANNEL_H

#include <vector>

class Channel {
public:
    virtual ~Channel() = default;

    virtual std::vector<double> transmit(
        const std::vector<double>& signal,
        double snrDb
    ) const = 0;
};

#endif
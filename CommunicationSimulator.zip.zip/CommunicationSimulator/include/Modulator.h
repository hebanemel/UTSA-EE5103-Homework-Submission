#ifndef MODULATOR_H
#define MODULATOR_H

#include <vector>
#include <string>

class Modulator {
public:
    virtual ~Modulator() = default;

    virtual std::vector<double> modulate(const std::vector<int>& bits) const = 0;
    virtual std::vector<int> demodulate(const std::vector<double>& received) const = 0;
    virtual std::string getName() const = 0;
};

#endif
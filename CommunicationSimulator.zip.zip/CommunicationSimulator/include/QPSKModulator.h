#ifndef QPSKMODULATOR_H
#define QPSKMODULATOR_H

#include "Modulator.h"

class QPSKModulator : public Modulator {
public:
    std::vector<double> modulate(const std::vector<int>& bits) const override;
    std::vector<int> demodulate(const std::vector<double>& received) const override;
    std::string getName() const override;
};

#endif
#ifndef SIMULATION_H
#define SIMULATION_H

#include "Modulator.h"
#include "Channel.h"

class Simulation {
private:
    int numBits_;
    double snrDb_;
    const Modulator& modulator_;
    const Channel& channel_;

public:
    Simulation(
        int numBits,
        double snrDb,
        const Modulator& modulator,
        const Channel& channel
    );

    void run() const;
};

#endif
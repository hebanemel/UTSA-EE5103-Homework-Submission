#ifndef STATISTICS_H
#define STATISTICS_H

#include <vector>

class Statistics {
public:
    static int countErrors(
        const std::vector<int>& original,
        const std::vector<int>& received
    );

    static double computeBER(
        const std::vector<int>& original,
        const std::vector<int>& received
    );

    static double computeSER(
        const std::vector<int>& original,
        const std::vector<int>& received
    ) {
        int errors = countErrors(original, received);
        return static_cast<double>(errors) / (original.size() / 2); // Assuming 2 bits per symbol
    }
};

#endif
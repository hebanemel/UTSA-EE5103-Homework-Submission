#include "AWGNChannel.h"
#include <random>
#include <cmath>

double AWGNChannel::computeNoiseStdDev(double snrDb) const {
    double snrLinear = std::pow(10.0, snrDb / 10.0);
    return std::sqrt(1.0 / (2.0 * snrLinear));
}

std::vector<double> AWGNChannel::transmit(
    const std::vector<double>& signal,
    double snrDb
) const {
    std::vector<double> received;
    std::default_random_engine gen;
    double sigma = computeNoiseStdDev(snrDb);
    std::normal_distribution<double> noise(0.0, sigma);

    for (double s : signal) {
        received.push_back(s + noise(gen));
    }
    return received;
}
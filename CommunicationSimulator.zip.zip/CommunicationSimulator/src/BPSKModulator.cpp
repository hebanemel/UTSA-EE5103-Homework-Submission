#include "BPSKModulator.h"

std::vector<double> BPSKModulator::modulate(const std::vector<int>& bits) const {
    std::vector<double> symbols;
    for (int b : bits) {
        symbols.push_back(b == 1 ? 1.0 : -1.0);
    }
    return symbols;
}

std::vector<int> BPSKModulator::demodulate(const std::vector<double>& received) const {
    std::vector<int> bits;
    for (double r : received) {
        bits.push_back(r >= 0 ? 1 : 0);
    }
    return bits;
}

std::string BPSKModulator::getName() const {
    return "BPSK";
}
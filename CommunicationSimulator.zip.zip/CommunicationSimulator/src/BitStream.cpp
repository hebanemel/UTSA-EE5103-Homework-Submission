#include "BitStream.h"
#include <random>

BitStream::BitStream() {}

BitStream::BitStream(int size) {
    generateRandomBits(size);
}

void BitStream::generateRandomBits(int size) {
    bits_.clear();
    std::default_random_engine gen;
    std::uniform_int_distribution<int> dist(0, 1);

    for (int i = 0; i < size; ++i) {
        bits_.push_back(dist(gen));
    }
}

const std::vector<int>& BitStream::getBits() const {
    return bits_;
}
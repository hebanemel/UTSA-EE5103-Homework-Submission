#include "QPSKModulator.h"

std::vector<double> QPSKModulator::modulate(const std::vector<int>& bits) const {
    std::vector<double> symbols;

    for (size_t i = 0; i < bits.size(); i += 2) {
        int b1 = bits[i];
        int b2 = (i + 1 < bits.size()) ? bits[i + 1] : 0;

        // Simple mapping
        double symbol = (b1 == 1 ? 1.0 : -1.0) + (b2 == 1 ? 0.5 : -0.5);
        symbols.push_back(symbol);
    }

    return symbols;
}

std::vector<int> QPSKModulator::demodulate(const std::vector<double>& received) const {
    std::vector<int> bits;

    for (double r : received) {
        bits.push_back(r >= 0 ? 1 : 0);
        bits.push_back(r >= 0 ? 1 : 0);
    }

    return bits;
}

std::string QPSKModulator::getName() const {
    return "QPSK";
}
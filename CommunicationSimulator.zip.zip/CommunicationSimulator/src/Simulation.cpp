#include "Simulation.h"
#include "BitStream.h"
#include "Statistics.h"
#include <iostream>

Simulation::Simulation(
    int numBits,
    double snrDb,
    const Modulator& modulator,
    const Channel& channel
) : numBits_(numBits), snrDb_(snrDb), modulator_(modulator), channel_(channel) {}

void Simulation::run() const {
    BitStream source(numBits_);
    auto bits = source.getBits();

    auto symbols = modulator_.modulate(bits);
    auto received = channel_.transmit(symbols, snrDb_);
    auto detected = modulator_.demodulate(received);

    double ber = Statistics::computeBER(bits, detected);

    std::cout << "Modulation: " << modulator_.getName() << std::endl;
    std::cout << "SNR (dB): " << snrDb_ << std::endl;
    std::cout << "errors: " << Statistics::countErrors(bits, detected) << std::endl;
    std::cout << "BER: " << ber << std::endl;
}
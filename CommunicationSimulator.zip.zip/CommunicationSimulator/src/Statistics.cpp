#include "Statistics.h"

int Statistics::countErrors(
    const std::vector<int>& original,
    const std::vector<int>& received
) {
    int errors = 0;
    for (size_t i = 0; i < original.size(); ++i) {
        if (original[i] != received[i]) errors++;
    }
    return errors;
}

double Statistics::computeBER(
    const std::vector<int>& original,
    const std::vector<int>& received
) {
    int errors = countErrors(original, received);
    return static_cast<double>(errors) / original.size();
}